<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller']   = 'welcome';
$route['404_override']         = 'MyCustom404Ctrl';
$route['translate_uri_dashes'] = TRUE;

$route['login']                = 'user/login';
$route['logout']               = 'user/logout';
$route['admin']                = 'admin/dashboard';

$route['sitemap\.xml']         = 'sitemap';
