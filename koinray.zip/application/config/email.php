<?php

$config['protocol'] = 'mail';
$config['charset'] = 'utf8';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;

// Uncomment the code below and delete the previous one to use the SMTP

/* SMTP mail
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.coinsure.net';
$config['smtp_port'] = '25';
$config['smtp_user'] = 'admin@coinsure.net';
$config['smtp_pass'] = 'Maulik@260499';
$config['charset'] = 'utf8';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;
*/

?>