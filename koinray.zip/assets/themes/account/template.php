<?php defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html class="fontawesome-i2svg-active fontawesome-i2svg-complete"><style type="text/css" id="night-mode-pro-style"></style><link type="text/css" id="dark-mode" rel="stylesheet" href=""><style type="text/css" id="dark-mode-custom-style"></style><link type="text/css" rel="stylesheet" id="night-mode-pro-link">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Just Digital Tech">
     <style type="text/css">svg:not(:root).svg-inline--fa{overflow:visible}.svg-inline--fa{display:inline-block;font-size:inherit;height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-lg{vertical-align:-.225em}.svg-inline--fa.fa-w-1{width:.0625em}.svg-inline--fa.fa-w-2{width:.125em}.svg-inline--fa.fa-w-3{width:.1875em}.svg-inline--fa.fa-w-4{width:.25em}.svg-inline--fa.fa-w-5{width:.3125em}.svg-inline--fa.fa-w-6{width:.375em}.svg-inline--fa.fa-w-7{width:.4375em}.svg-inline--fa.fa-w-8{width:.5em}.svg-inline--fa.fa-w-9{width:.5625em}.svg-inline--fa.fa-w-10{width:.625em}.svg-inline--fa.fa-w-11{width:.6875em}.svg-inline--fa.fa-w-12{width:.75em}.svg-inline--fa.fa-w-13{width:.8125em}.svg-inline--fa.fa-w-14{width:.875em}.svg-inline--fa.fa-w-15{width:.9375em}.svg-inline--fa.fa-w-16{width:1em}.svg-inline--fa.fa-w-17{width:1.0625em}.svg-inline--fa.fa-w-18{width:1.125em}.svg-inline--fa.fa-w-19{width:1.1875em}.svg-inline--fa.fa-w-20{width:1.25em}.svg-inline--fa.fa-pull-left{margin-right:.3em;width:auto}.svg-inline--fa.fa-pull-right{margin-left:.3em;width:auto}.svg-inline--fa.fa-border{height:1.5em}.svg-inline--fa.fa-li{width:2em}.svg-inline--fa.fa-fw{width:1.25em}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:#ff253a;border-radius:1em;-webkit-box-sizing:border-box;box-sizing:border-box;color:#fff;height:1.5em;line-height:1;max-width:5em;min-width:1.5em;overflow:hidden;padding:.25em;right:0;text-overflow:ellipsis;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:0;right:0;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:0;left:0;right:auto;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{right:0;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:0;right:auto;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top left;transform-origin:top left}.fa-lg{font-size:1.33333em;line-height:.75em;vertical-align:-.0667em}.fa-xs{font-size:.75em}.fa-sm{font-size:.875em}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:2.5em;padding-left:0}.fa-ul>li{position:relative}.fa-li{left:-2em;position:absolute;text-align:center;width:2em;line-height:inherit}.fa-border{border:solid .08em #eee;border-radius:.1em;padding:.2em .25em .15em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left,.fab.fa-pull-left,.fal.fa-pull-left,.far.fa-pull-left,.fas.fa-pull-left{margin-right:.3em}.fa.fa-pull-right,.fab.fa-pull-right,.fal.fa-pull-right,.far.fa-pull-right,.fas.fa-pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}:root .fa-flip-horizontal,:root .fa-flip-vertical,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-rotate-90{-webkit-filter:none;filter:none}.fa-stack{display:inline-block;height:2em;position:relative;width:2em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.svg-inline--fa.fa-stack-1x{height:1em;width:1em}.svg-inline--fa.fa-stack-2x{height:2em;width:2em}.fa-inverse{color:#fff}.sr-only{border:0;clip:rect(0,0,0,0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.sr-only-focusable:active,.sr-only-focusable:focus{clip:auto;height:auto;margin:0;overflow:visible;position:static;width:auto}</style><link rel="shortcut icon" type="image/x-icon" href="/favicon.ico?v=2.0.4">
	  <link rel="icon" type="image/x-icon" href="/favicon.ico?v=2.0.4">
    <title><?php echo $page_title; ?> - <?php echo $this->settings->site_name; ?></title>
		<meta name="keywords" content="<?php echo $this->settings->meta_keywords; ?>">
    <meta name="description" content="<?php echo $this->settings->meta_description; ?>">

    <!-- Bootstrap core CSS -->
    <link href="/assets/themes/account/css/bootstrap.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="/assets/themes/account/css/escrow.css?rand=2170699" rel="stylesheet">
    <link href="/assets/themes/global/custom.css?rand=1968939" rel="stylesheet">
		<script async="" src="https://buttons-config.sharethis.com/js/5a9be2e82326af0013ae4037.js"></script>
		<script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/api2/v1545073489967/recaptcha__en_gb.js"></script>
		<script src="/assets/themes/global/custom.js?rand=9101783"></script>
		<link href="/assets/themes/account/css/countrySelect.css" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
		<link href="/assets/themes/account/css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		<script src="https://www.google.com/recaptcha/api.js"></script>
		<script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=5a9be2e82326af0013ae4037&amp;product=inline-share-buttons"></script>
		
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="/assets/themes/account/js/link-initialize.js"></script>
		<script defer="" src="https://use.fontawesome.com/releases/v5.3.1/js/all.js" integrity="sha384-kW+oWsYx3YpxvjtZjFXqazFpA7UP/MbiY4jvs+RWZo2+N94PFZ36T6TFkc9O3qoB" crossorigin="anonymous"></script>
</head>
	
	<?php // Notify invoice
		$info_invoices = $this->notice->sum_user_invoices($user['username']);
		if ($info_invoices > 0) {
			$sample_invoice = TRUE;
		} else {
			$sample_invoice = FALSE;
		}
	?>
	
	<?php // Notify support
		$info_support = $this->notice->sum_user_support($user['username']);
		if ($info_invoices > 0) {
			$sample_support = TRUE;
		} else {
			$sample_support = FALSE;
		}
	?>
	
<body class="listpage  theme-dark page-accountpage-transactions">
	
	<nav class="navbar navbar-expand-md navbar-dark">
		<div class="container">
      <a class="navbar-brand" href="#">
				<img src="<?php echo base_url();?>assets/themes/account/img/main-logo.png" height="30" alt="">
			</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item <?php echo (uri_string() == '') ? 'active' : ''; ?>">
            <a class="nav-link" href="<?php echo base_url('/'); ?>"><?php echo lang('core button home'); ?></a>
          </li>
					<li class="nav-item <?php echo (uri_string() == 'how-it-works') ? 'active' : ''; ?>">
            <a class="nav-link" href="<?php echo base_url('/how-it-works'); ?>"><?php echo lang('core button how_it'); ?></a>
          </li>
					<li class="nav-item <?php echo (uri_string() == 'developers') ? 'active' : ''; ?>">
            <a class="nav-link" href="<?php echo base_url('/developers'); ?>"><?php echo lang('core button developer'); ?></a>
          </li>
					<li class="nav-item <?php echo (uri_string() == 'help') ? 'active' : ''; ?>">
            <a class="nav-link" href="<?php echo base_url('/help'); ?>"><?php echo lang('core button help'); ?></a>
          </li>
          <li class="nav-item <?php echo (uri_string() == 'contact') ? 'active' : ''; ?>">
            <a class="nav-link" href="<?php echo base_url('/contact'); ?>"><?php echo lang('core button contact'); ?></a>
          </li>
         
        </ul>
        <div class="form-inline my-2 my-lg-0">
					<?php if ($this->session->userdata('logged_in')) : ?>
          <?php if ($this->user['is_admin']) : ?>
					<div class="nav-user">
						<a href="<?php echo base_url('admin'); ?>" class="my-2 my-sm-0 mr-3"><?php echo lang('core button admin'); ?></a>
					</div>
					<?php endif; ?>
					<div class="nav-user">
						<a href="<?php echo base_url('logout'); ?>" class="my-2 my-sm-0 mr-3"><?php echo lang('core button logout'); ?></a>
					</div>
					<a href="<?php echo base_url('account/transactions'); ?>" class="btn btn-success my-2 my-sm-0"><?php echo lang('users menu my_account'); ?></a>
					<?php else : ?>
          <a href="<?php echo base_url('login'); ?>" class="btn btn-outline-light my-2 my-sm-0 mr-3"><?php echo lang('core button sign_in'); ?></a>
          <a href="<?php echo base_url('user/register'); ?>" class="btn btn-success my-2 my-sm-0"><?php echo lang('core button create'); ?></a>
					<?php endif; ?>
        </div>	
      </div>
		</div>
    </nav>
	
		<div class="header-st">
			<div class="bottom-sec">
				<div class="container">
				<div class="row">
					<div class="col-md-8 col-sm-6 col-xs-6 mt-0">
						<div class="row">
							<div class="col-md-5">
								<div class="avail-balance">
								<div class="label">Available balance</div>
            					<div class="dropdown">
									<button class="btn-ballance btn-link dropdown-toggle btn-block-head" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<?php echo $this->notice->hold_balance($user['username'], "debit_base", 1); ?> <?php echo $this->currencys->display->base_code ?>
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<?php if($this->currencys->display->extra1_check) : ?>
										<a class="dropdown-item" href="#">
											 <div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra1", 1); ?> 
											 <h5 style="text-transform: none;"><?php echo $this->currencys->display->extra1_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra2_check) : ?>
										<a class="dropdown-item" href="#">
											<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra2", 1); ?>
											 <h5 style="text-transform: none;">
											 <?php echo $this->currencys->display->extra2_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra3_check) : ?>
										<a class="dropdown-item" href="#">
										<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra3", 1); ?> 
											 <h5 style="text-transform: none;">
											 <?php echo $this->currencys->display->extra3_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra4_check) : ?>
										<a class="dropdown-item" href="#">
											<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra4", 1); ?> 
											 <h5 style="text-transform: none;">
											 <?php echo $this->currencys->display->extra4_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra5_check) : ?>
										<a class="dropdown-item" href="#">
											<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra5", 1); ?> 
											 <h5 style="text-transform: none;">
											 <?php echo $this->currencys->display->extra5_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
									</div>
								</div>
							</div>
							</div>
							<div class="col-md-5">
								<div class="hold-balance">
								<div class="label">Hold balance</div>
            		<div class="dropdown">
									<button class="btn-ballance btn-link dropdown-toggle btn-block-head" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<?php echo $this->notice->hold_balance($user['username'], "debit_base", 2); ?> <?php echo $this->currencys->display->base_code ?>
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<?php if($this->currencys->display->extra1_check) : ?>
										<a class="dropdown-item" href="#">
										<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 	<?php echo $this->notice->hold_balance($user['username'], "debit_extra1", 2); ?>
											 <h5 style="text-transform: none;">
											  <?php echo $this->currencys->display->extra1_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra2_check) : ?>
										<a class="dropdown-item" href="#">
											<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 	<?php echo $this->notice->hold_balance($user['username'], "debit_extra2", 2); ?>
											 <h5 style="text-transform: none;"> <?php echo $this->currencys->display->extra2_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra3_check) : ?>
										<a class="dropdown-item" href="#">
											<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra3", 2); ?> 
											 <h5 style="text-transform: none;"><?php echo $this->currencys->display->extra3_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra4_check) : ?>
										<a class="dropdown-item" href="#">
											<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 <?php echo $this->notice->hold_balance($user['username'], "debit_extra4", 2); ?> 
											 <h5 style="text-transform: none;"><?php echo $this->currencys->display->extra4_code ?>
											</h5>
											</h4>
										</a>
										<?php endif; ?>
										<?php if($this->currencys->display->extra5_check) : ?>
										<a class="dropdown-item" href="#">
										<div><img src="/assets/images/coins/usd.png"></div>
											 <h4>
											 	<?php echo $this->notice->hold_balance($user['username'], "debit_extra5", 2); ?>
											 	<h5 style="text-transform: none;"> <?php echo $this->currencys->display->extra5_code ?>
											 	</h5>
											</h4>
										</a>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
						</div>
					</div>
					

					
					<div class="col-md-4 col-sm-4 col-xs-4 text-right">
						<div class="btn-group" role="group" aria-label="Basic example">
							<a href="orders" class="btn"><i class="icon-badge icons"></i> My orders</a>
							<a href="cart" class="btn"><i class="icon-basket icons"></i> My cart <span class="badge badge-pill badge-danger">0</span></a> 
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
    	<main>
    <div class="container theme-showcase" role="main">
			<div class="row">
				<div class="col-md-6 mt-4">
					<h1><?php echo $page_header; ?></h1>
				</div>
				<div class="col-md-6 mt-4 text-right Deposit mb-4">
					<div class="btn-group header-bar" role="group" aria-label="Deposit">
							<a href="/account/deposit" class="depo btn btn-lg min-width-120">Deposit</a>
							<a href="/account/withdrawal" class="withdraw btn btn-lg min-width-120">Withdrawal</a>
						</div>
				</div>
				<div class="col-md-12">
				<hr>
				</div>
				<div class="col-md-3 mt-3 sidenav">
					<div class="list-group">
						<a href="<?php echo base_url('account/transactions'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/transactions') ? 'active' : ''; ?>">
							<svg class="svg-inline--fa fa-list-ul fa-w-16 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="list-ul" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M96 96c0 26.51-21.49 48-48 48S0 122.51 0 96s21.49-48 48-48 48 21.49 48 48zM48 208c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zm0 160c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zm96-236h352c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H144c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h352c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H144c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h352c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H144c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path></svg>
							<?php echo lang('users title history'); ?><span class="text-right">
						</a>
						<a href="<?php echo base_url('account/money_transfer'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/money_transfer') ? 'active' : ''; ?>">
							<svg class="svg-inline--fa fa-arrow-right fa-w-14 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="arrow-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"></path></svg>
							<?php echo lang('users menu transfer'); ?><span class="text-right">
						</a>

							<a href="<?php echo base_url('account/shops'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/shops') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-credit-card fa-w-18 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="credit-card" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" data-fa-i2svg=""><path fill="currentColor" d="M0 432c0 26.5 21.5 48 48 48h480c26.5 0 48-21.5 48-48V256H0v176zm192-68c0-6.6 5.4-12 12-12h136c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12H204c-6.6 0-12-5.4-12-12v-40zm-128 0c0-6.6 5.4-12 12-12h72c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12H76c-6.6 0-12-5.4-12-12v-40zM576 80v48H0V80c0-26.5 21.5-48 48-48h480c26.5 0 48 21.5 48 48z"></path></svg>
							<?php echo lang('users shops title'); ?><span class="text-right">
						  </a>
							<a href="<?php echo base_url('account/exchange'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/exchange') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-hand-holding-usd fa-w-17 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="hand-holding-usd" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 544 512" data-fa-i2svg=""><path fill="currentColor" d="M257.6 144.3l50 14.3c3.6 1 6.1 4.4 6.1 8.1 0 4.6-3.8 8.4-8.4 8.4h-32.8c-3.6 0-7.1-.8-10.3-2.2-4.8-2.2-10.4-1.7-14.1 2l-17.5 17.5c-5.3 5.3-4.7 14.3 1.5 18.4 9.5 6.3 20.3 10.1 31.8 11.5V240c0 8.8 7.2 16 16 16h16c8.8 0 16-7.2 16-16v-17.6c30.3-3.6 53.3-31 49.3-63-2.9-23-20.7-41.3-42.9-47.7l-50-14.3c-3.6-1-6.1-4.4-6.1-8.1 0-4.6 3.8-8.4 8.4-8.4h32.8c3.6 0 7.1.8 10.3 2.2 4.8 2.2 10.4 1.7 14.1-2l17.5-17.5c5.3-5.3 4.7-14.3-1.5-18.4-9.5-6.3-20.3-10.1-31.8-11.5V16c0-8.8-7.2-16-16-16h-16c-8.8 0-16 7.2-16 16v17.6c-30.3 3.6-53.3 31-49.3 63 2.9 23 20.7 41.3 42.9 47.7zm276.3 183.8c-11.2-10.7-28.5-10-40.3 0L406.4 402c-10.7 9.1-24 14-37.8 14H256.9c-8.3 0-15.1-7.2-15.1-16s6.8-16 15.1-16h73.9c15.1 0 29-10.9 31.4-26.6 3.1-20-11.5-37.4-29.8-37.4H181.3c-25.5 0-50.2 9.3-69.9 26.3L67.5 384H15.1C6.8 384 0 391.2 0 400v96c0 8.8 6.8 16 15.1 16H352c13.7 0 27-4.9 37.8-14l142.8-121c14.4-12.1 15.5-35.3 1.3-48.9z"></path></svg>
							<?php echo lang('users menu exchange'); ?><span class="text-right">
						 </a>
							

							<a href="<?php echo base_url('account/invoices'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/invoices') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-receipt fa-w-12 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="receipt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg=""><path fill="currentColor" d="M358.4 3.2L320 48 265.6 3.2a15.9 15.9 0 0 0-19.2 0L192 48 137.6 3.2a15.9 15.9 0 0 0-19.2 0L64 48 25.6 3.2C15-4.7 0 2.8 0 16v480c0 13.2 15 20.7 25.6 12.8L64 464l54.4 44.8a15.9 15.9 0 0 0 19.2 0L192 464l54.4 44.8a15.9 15.9 0 0 0 19.2 0L320 464l38.4 44.8c10.5 7.9 25.6.4 25.6-12.8V16c0-13.2-15-20.7-25.6-12.8zM320 360c0 4.4-3.6 8-8 8H72c-4.4 0-8-3.6-8-8v-16c0-4.4 3.6-8 8-8h240c4.4 0 8 3.6 8 8v16zm0-96c0 4.4-3.6 8-8 8H72c-4.4 0-8-3.6-8-8v-16c0-4.4 3.6-8 8-8h240c4.4 0 8 3.6 8 8v16zm0-96c0 4.4-3.6 8-8 8H72c-4.4 0-8-3.6-8-8v-16c0-4.4 3.6-8 8-8h240c4.4 0 8 3.6 8 8v16z"></path></svg>
								<?php echo lang('users invoices menu'); ?> <span class="text-right">
								<?if($info_invoices == TRUE){?>
								<span class="notification-badge">
									<?php echo $this->notice->sum_user_invoices($user['username']); ?>
								</span>
								<?}else{?>
								
  							<?}?>
							</a>
							<a href="<?php echo base_url('account/vouchers'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/vouchers') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-gift fa-w-16 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="gift" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M32 448c0 17.7 14.3 32 32 32h160V320H32v128zm448-288h-42.1c6.2-12.1 10.1-25.5 10.1-40 0-48.5-39.5-88-88-88-41.6 0-68.5 21.3-103 68.3-34.5-47-61.4-68.3-103-68.3-48.5 0-88 39.5-88 88 0 14.5 3.8 27.9 10.1 40H32c-17.7 0-32 14.3-32 32v80c0 8.8 7.2 16 16 16h480c8.8 0 16-7.2 16-16v-80c0-17.7-14.3-32-32-32zm-326.1 0c-22.1 0-40-17.9-40-40s17.9-40 40-40c19.9 0 34.6 3.3 86.1 80h-86.1zm206.1 0h-86.1c51.4-76.5 65.7-80 86.1-80 22.1 0 40 17.9 40 40s-17.9 40-40 40zm-72 320h160c17.7 0 32-14.3 32-32V320H288v160z"></path></svg>
							<?php echo lang('users vouchers menu'); ?><span class="text-right">
							</a>
							<a href="<?php echo base_url('account/disputes'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/disputes') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-hands-helping fa-w-20 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="hands-helping" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" data-fa-i2svg=""><path fill="currentColor" d="M488 192H336v56c0 39.7-32.3 72-72 72s-72-32.3-72-72V126.4l-64.9 39C107.8 176.9 96 197.8 96 220.2v47.3l-80 46.2C.7 322.5-4.6 342.1 4.3 357.4l80 138.6c8.8 15.3 28.4 20.5 43.7 11.7L231.4 448H368c35.3 0 64-28.7 64-64h16c17.7 0 32-14.3 32-32v-64h8c13.3 0 24-10.7 24-24v-48c0-13.3-10.7-24-24-24zm147.7-37.4L555.7 16C546.9.7 527.3-4.5 512 4.3L408.6 64H306.4c-12 0-23.7 3.4-33.9 9.7L239 94.6c-9.4 5.8-15 16.1-15 27.1V248c0 22.1 17.9 40 40 40s40-17.9 40-40v-88h184c30.9 0 56 25.1 56 56v28.5l80-46.2c15.3-8.9 20.5-28.4 11.7-43.7z"></path></svg>
							<?php echo lang('users menu dispute'); ?><span class="text-right">
							</a>
							<a href="<?php echo base_url('account/merchants'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/merchants') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-hands-helping fa-w-20 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="hands-helping" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" data-fa-i2svg=""><path fill="currentColor" d="M488 192H336v56c0 39.7-32.3 72-72 72s-72-32.3-72-72V126.4l-64.9 39C107.8 176.9 96 197.8 96 220.2v47.3l-80 46.2C.7 322.5-4.6 342.1 4.3 357.4l80 138.6c8.8 15.3 28.4 20.5 43.7 11.7L231.4 448H368c35.3 0 64-28.7 64-64h16c17.7 0 32-14.3 32-32v-64h8c13.3 0 24-10.7 24-24v-48c0-13.3-10.7-24-24-24zm147.7-37.4L555.7 16C546.9.7 527.3-4.5 512 4.3L408.6 64H306.4c-12 0-23.7 3.4-33.9 9.7L239 94.6c-9.4 5.8-15 16.1-15 27.1V248c0 22.1 17.9 40 40 40s40-17.9 40-40v-88h184c30.9 0 56 25.1 56 56v28.5l80-46.2c15.3-8.9 20.5-28.4 11.7-43.7z"></path></svg>
							<?php echo lang('users shops merchant'); ?><span class="text-right">
							</a>
							<a href="<?php echo base_url('account/support'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/support') ? 'active' : ''; ?>">
								<svg class="svg-inline--fa fa-question-circle fa-w-16 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="question-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zM262.655 90c-54.497 0-89.255 22.957-116.549 63.758-3.536 5.286-2.353 12.415 2.715 16.258l34.699 26.31c5.205 3.947 12.621 3.008 16.665-2.122 17.864-22.658 30.113-35.797 57.303-35.797 20.429 0 45.698 13.148 45.698 32.958 0 14.976-12.363 22.667-32.534 33.976C247.128 238.528 216 254.941 216 296v4c0 6.627 5.373 12 12 12h56c6.627 0 12-5.373 12-12v-1.333c0-28.462 83.186-29.647 83.186-106.667 0-58.002-60.165-102-116.531-102zM256 338c-25.365 0-46 20.635-46 46 0 25.364 20.635 46 46 46s46-20.636 46-46c0-25.365-20.635-46-46-46z"></path></svg>
								<?php echo lang('users support title_1'); ?> <span class="text-right">
								<?if($info_support == TRUE){?>
								<span class="notification-badge">
									<?php echo $this->notice->sum_user_support($user['username']); ?>
								</span>
								<?}else{?>
								
  							<?}?>
						</a>
						<a href="<?php echo base_url('account/settings'); ?>" class="list-group-item  d-flex align-items-center list-group-item-action <?php echo (uri_string() == 'account/settings') ? 'active' : ''; ?>">
							<svg class="svg-inline--fa fa-sliders-h fa-w-16 fa-2x mt-2" aria-hidden="true" data-prefix="fas" data-icon="sliders-h" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M496 384H160v-16c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v16H16c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h80v16c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16v-16h336c8.8 0 16-7.2 16-16v-32c0-8.8-7.2-16-16-16zm0-160h-80v-16c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v16H16c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h336v16c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16v-16h80c8.8 0 16-7.2 16-16v-32c0-8.8-7.2-16-16-16zm0-160H288V48c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v16H16C7.2 64 0 71.2 0 80v32c0 8.8 7.2 16 16 16h208v16c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16v-16h208c8.8 0 16-7.2 16-16V80c0-8.8-7.2-16-16-16z"></path></svg>
							<?php echo lang('users settings title'); ?><span class="text-right">
						</a>
					</div>
				</div>
				<div class="col-md-9 mt-3">
						<?php // System messages ?>
						<?php if ($this->session->flashdata('message')) : ?>
							<div class="alert alert-success alert-dismissible fade show" role="alert">
								<?php echo $this->session->flashdata('message'); ?>
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						<?php elseif ($this->session->flashdata('error')) : ?>
								<div class="alert alert-danger alert-dismissible fade show" role="alert">
									<?php echo $this->session->flashdata('error'); ?>
									<button type="button" class="close" data-dismiss="alert" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
						<?php elseif (validation_errors()) : ?>
								<div class="alert alert-danger alert-dismissible fade show" role="alert">
									<?php echo validation_errors(); ?>
									<button type="button" class="close" data-dismiss="alert" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
						<?php elseif ($this->error) : ?>
								<div class="alert alert-danger alert-dismissible fade show" role="alert">
									 <?php echo $this->error; ?>
									<button type="button" class="close" data-dismiss="alert" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
						<?php endif; ?>
						<?php // Main content ?>
        		<?php echo $content; ?>
				</div>
			</div>
        

    </div>
	</main>
								

    <?php // Footer ?>
    <footer>
			
			<div class="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-10">
							<ul class="list-inline">
								<li class="list-inline-item mr-4"><a href="<?php echo base_url('agreement'); ?>"><?php echo lang('core button terms'); ?></a></li>
								<li class="list-inline-item mr-4"><a href="<?php echo base_url('privacy'); ?>"><?php echo lang('core button privacy'); ?></a></li>
								<li class="list-inline-item mr-4"><a href="<?php echo base_url('instructions'); ?>"><?php echo lang('core button instructions'); ?></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
        
    </footer>
	
	 <!-- Placed at the end of the document so the pages load faster 
	
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
<script src="<?php echo base_url();?>assets/themes/account/js/countrySelect.min.js"></script>
<script>
  $("#country").countrySelect();
</script>

<script>
	var position = 0;
	var scrollHeight = Math.max(
  document.body.scrollHeight, document.documentElement.scrollHeight,
  document.body.offsetHeight, document.documentElement.offsetHeight,
  document.body.clientHeight, document.documentElement.clientHeight
);

$(window).scroll(function(e) {
  var $element = $('.header-st');
  var scrollTop = $(this).scrollTop();
  if( scrollTop <= 10 ) { 
    $element.removeClass('hide').removeClass('scrolling');
  } else if( scrollTop < position ) {
    $element.removeClass('hide');
  } else if( scrollTop > position && scrollHeight > 1000) {
    $element.addClass('scrolling');
    if( scrollTop + $(window).height() >=  $(document).height() - $element.height() ){
      $element.removeClass('hide');
    } else if(Math.abs($element.position().top) < $element.height()) {
      $element.addClass('hide');
    }
  }
  position = scrollTop;
})			
</script>
-->	
							
	
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
<script>
$(function () {
	$('[data-toggle="tooltip"]').tooltip()
})
</script>
<script src="<?php echo base_url();?>assets/themes/account/js/countrySelect.min.js"></script>
<script>
  $("#country").countrySelect();
</script>
<script src="<?php echo base_url();?>assets/themes/account/js/datepicker.js"></script>
<script>

$.fn.datepicker.language['ru'] = {days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    daysShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    daysMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
    months: ['January','February','March','April','May','June', 'July','August','September','October','November','December'],
    monthsShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    today: 'Today',
    clear: 'Clear',
    dateFormat: 'yyyy-mm-dd',
    timeFormat: 'hh:ii',
    firstDay: 0}
</script>

<?php // Javascript files ?>
    <?php if (isset($js_files) && is_array($js_files)) : ?>
        <?php foreach ($js_files as $js) : ?>
            <?php if ( ! is_null($js)) : ?>
                <?php $separator = (strstr($js, '?')) ? '&' : '?'; ?>
                <?php echo "\n"; ?><script type="text/javascript" src="<?php echo $js; ?><?php echo $separator; ?>v=<?php echo $this->settings->site_version; ?>"></script><?php echo "\n"; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>
    <?php if (isset($js_files_i18n) && is_array($js_files_i18n)) : ?>
        <?php foreach ($js_files_i18n as $js) : ?>
            <?php if ( ! is_null($js)) : ?>
                <?php echo "\n"; ?><script type="text/javascript"><?php echo "\n" . $js . "\n"; ?></script><?php echo "\n"; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>
							
</body>
</html>