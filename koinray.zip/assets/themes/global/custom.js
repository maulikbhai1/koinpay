window.onload=function(){
  const depositEl = document.querySelector(".col-md-6.mt-4.text-right.Deposit.mb-4");
//  console.log(depositEl);

  // create button container
  const btnDiv = document.createElement("div");
  btnDiv.classList.add("col-md-6", "mt-4", "text-center", "mb-4");
btnDiv.classList.add("tools-btn-container");
  // creating button
  const accountTools = document.createElement("button");
  accountTools.textContent = "Show Account Tools";
  accountTools.style.cssText = "background-color: #0B0F24;border-color: #292F51;color: #C32AFF;border-radius: 25px;padding: 0.5rem 3rem;font-size: 1.25rem;";
  accountTools.id = "account-tools";

  btnDiv.appendChild(accountTools);

  // insert the html
  depositEl.insertAdjacentElement("afterend", btnDiv);


// function to hide / show side menu
const sidenav = document.querySelector(".sidenav");
let activeItem = document.querySelector("body .list-group-item.active");

console.log(activeItem);
/*accountTools.addEventListener("click", function(){
  if (sidenav.style.display == ""){
    sidenav.style.display = "block";
accountTools.style.cssText = "background-color: #fff;color: #bc2de7;border-color: #bc2de7;border-radius: 25px;padding: 0.5rem 3rem;font-size: 1.25rem;";
accountTools.textContent = "Hide Account Tools";
  } else if (sidenav.style.display === "block") {
    sidenav.style.display = "none";
    accountTools.style.cssText = "background-color: #0B0F24;border-color: #292F51;color: #C32AFF;border-radius: 25px;padding: 0.5rem 3rem;font-size: 1.25rem;";
    accountTools.textContent = "Show Account Tools";
  } else {
    sidenav.style.display = "block";
    accountTools.style.cssText = "background-color: #fff;color: #bc2de7;border-color: #bc2de7;border-radius: 25px;padding: 0.5rem 3rem;font-size: 1.25rem;";
    accountTools.textContent = "Hide Account Tools";
  }
})*/

accountTools.addEventListener("click", function(){
sidenav.classList.toggle("show");

if (sidenav.classList.contains("show")){
  accountTools.classList.add("btn-style");
  accountTools.textContent = "Hide Account Tools";
  activeItem.classList.add("active-bg");
} else {
accountTools.classList.remove("btn-style");
accountTools.textContent = "Show Account Tools";
activeItem.classList.remove("active-bg");
}

})











}